from nepali_g2p.nepali_g2p import NepaliG2P

def test_nepali_to_phonemes():
    g2p = NepaliG2P()
    assert g2p.to_phonemes("नमस्ते") == "namaste"
    assert g2p.to_phonemes("हामी नेपाली हौं") == "haami nepaali haun"
    assert g2p.to_phonemes("सानो घरमा साना लड्डु छ") == "saano gharma saana laddu cha"
