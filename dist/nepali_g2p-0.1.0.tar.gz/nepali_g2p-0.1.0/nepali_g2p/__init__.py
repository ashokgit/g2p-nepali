from .nepali_g2p import NepaliG2P

__version__ = '1.0.0'